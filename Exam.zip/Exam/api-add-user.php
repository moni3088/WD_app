<?php

$fileName = "users.txt";

$user = json_decode('{}');
$user->id = uniqid();
$user->firstName = $_POST["firstName"];
$user->lastName = $_POST["lastName"];
$user->userName = $_POST["userName"];
$user->email = $_POST["email"];
$user->password = $_POST["password"];

$currentUsers = [];

$jsonString = file_get_contents($fileName);
$decodedUsers = json_decode($jsonString);

if ($decodedUsers != null) {
    $currentUsers = $decodedUsers;
}

array_push($currentUsers, $user);

$users = json_encode(array_values($currentUsers));

file_put_contents($fileName, $users);

echo $users;

?>