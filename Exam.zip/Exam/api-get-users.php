<?php

$sData = file_get_contents( 'users.txt' );
echo $sData;

?>