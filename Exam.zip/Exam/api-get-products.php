<?php

$sData = file_get_contents( 'products.txt' );
echo $sData;

?>